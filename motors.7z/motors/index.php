<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <meta name=keywords content="HTML, CSS, web development">
    <meta name=author content="Gheorghe Mitrea">
    <title> KK Motors.</title>

    <!-- CSS  -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="css/materialize.min.css" type="text/css" rel="stylesheet"/>
    <link href="css/style.css" type="text/css" rel="stylesheet"/>
</head>
<body>
  <nav class="blue darken-1">
    <div class="nav-wrapper container">

        <ul id="nav-mobile" class="side-nav">
            <li><a href="index.php">Home</a></li>
            <li><a href="index.php?page=services">Services</a></li>
            <!-- <li><a href="index.php?page=gallery">Gallery</a></li> -->
            <li><a href="index.php?page=gallery-new">Gallery</a></li>
            <li><a href="index.php?page=parts_accessories">Parts / Accessories</a></li>
            <li><a href="index.php?page=contact">Contact us</a></li>
            <li><a href="index.php?page=user">User Guide</a></li>

            <?php if (isset($_SESSION['usr_id'])): ?>
                <li><a href="#!" class="dropdown-button" data-activates="dropdown">Admin
                        <i class="material-icons right">arrow_drop_down</i>
                    </a>
                </li>
                <li><a href="index.php?page=logout">Log Out (<?php echo $_SESSION['usr_name']; ?>)</a></li>
                
            <?php else:  ?>
                <li><a href="index.php?page=login">Login</a></li>
                <li><a href="index.php?page=register">Sign Up</a></li>
            <?php endif; ?>
            <?php ?>
        </ul>
        <a href="#" data-activates="nav-mobile" class="button-collapse">
            <i class="material-icons">menu</i>
        </a>

        <ul class="dropdown-content" id="dropdown">
            <li><a href="index.php?page=register-car">Register Car</a></li>
            <li><a href="index.php?page=register-manufacturer">Register Manufacturer</a></li>
            <li><a href="index.php?page=register-carmodel">Register Car Model</a></li>
        </ul>
        <ul class="left hide-on-med-and-down">
            <li><a href="index.php">Home</a></li>
            <li><a href="index.php?page=services">Services</a></li>
            <!-- <li><a href="index.php?page=gallery">Gallery</a></li> -->
            <li><a href="index.php?page=gallery-new">Gallery</a></li>
            <li><a href="index.php?page=parts_accessories">Parts / Accessories</a></li>
            <li><a href="index.php?page=contact">Contact us</a></li>
            <li><a href="index.php?page=user">User Guide</a></li>
        </ul>

        <ul class="right hide-on-med-and-down">
            <?php if (isset($_SESSION['usr_id'])): ?>
                 <li><a href="#!" class="dropdown-button" data-activates="dropdown">Admin
                        <i class="material-icons right">arrow_drop_down</i>
                    </a>
                </li>
                <li><a href="index.php?page=logout">Log Out (<?php echo $_SESSION['usr_name']; ?>)</a></li>
               
            <?php else:  ?>
                <li><a href="index.php?page=login">Login</a></li>
                <li><a href="index.php?page=register">Sign Up</a></li>
            <?php endif; ?>
            <?php ?>
        </ul>
        </div>
    </nav>

    <!-- Select pages dinamically and include them here -->
    <?php
        if (isset($_GET['page'])) {
            include $_GET['page'];
        } else {
            include 'main';
        } /* otherwise, include the default page */
    ?>

    <footer class="page-footer red light">
        <div class="footer-copyright">
            <div class="container">
                Copyright &copy; 2017 Gheorghe MITREA. All rights reserved.
            </div>
        </div>
    </footer>

    <!--  Scripts-->
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/hammer.min.js"></script>
    <script src="js/materialize.min.js"></script>
    <script src="js/init.js"></script>
    <script src="http://maps.googleapis.com/maps/api/js"></script>
    <script>
        if(document.getElementById("googleMap")) {
            var myCenter = new google.maps.LatLng(51.508742, -0.120850);
            var map;
            var marker;

            function initialize() {
                var mapProp = {
                    center: myCenter,
                    zoom: 12,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                };
                map = new google.maps.Map(document.getElementById("googleMap"), mapProp);

                marker = new google.maps.Marker({
                    position: myCenter,
                    animation: google.maps.Animation.BOUNCE
                });

                marker.setMap(map);
            }

            google.maps.event.addDomListener(window, 'load', initialize);
            google.maps.event.addDomListener(window, "resize", function () {
                var center = map.getCenter();
                google.maps.event.trigger(map, "resize");
                map.setCenter(center);
            });
        }
    </script>

</body>
</html>
