CREATE DATABASE `testdb`;
USE `testdb`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(40) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

USE `testdb`;
CREATE TABLE IF NOT EXISTS `manufacturer` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_manufacturer` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=UTF8 AUTO_INCREMENT=1;

USE `testdb`;
CREATE TABLE IF NOT EXISTS `car_model` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `manufacturer_id` int(8) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_car_model` (`name`, `manufacturer_id`),
  CONSTRAINT `fk_car_model_manufacturer_manufacturer_id` FOREIGN KEY (`manufacturer_id`) REFERENCES `manufacturer` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=MyISAM  DEFAULT CHARSET=UTF8 AUTO_INCREMENT=1 ;

USE `testdb`;
CREATE TABLE IF NOT EXISTS `car` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `manufacturer_id` int(8) NOT NULL,
  `car_model_id` int(8) NOT NULL,
  `chassis_no` varchar(250) NOT NULL,
  `year` int(4) NOT NULL,
  `price` decimal(8, 2),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_car` (`chassis_no`),
  CONSTRAINT `fk_car_manufacturer_manufacturer_id` FOREIGN KEY (`manufacturer_id`) REFERENCES `manufacturer` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_car_car_model_car_model_id` FOREIGN KEY (`car_model_id`) REFERENCES `car_model` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=MyISAM  DEFAULT CHARSET=UTF8 AUTO_INCREMENT=1 ;

USE `testdb`;
CREATE TABLE IF NOT EXISTS `car_image` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `car_id` int(38) NOT NULL,
  `image_uri` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_car_image_car_car_id` FOREIGN KEY (`car_id`) REFERENCES `car` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=MyISAM  DEFAULT CHARSET=UTF8 AUTO_INCREMENT=1 ;
