<?php 
class User extends DataObject {
    // name: Table Name, key: Primary Key (can be an array), auto: AUTO_INCREMENT field
    protected static $_table = array('name' => 'Users', 'key' => 'UserID', 'auto' => 'UserID');
    // relationships between PHP properties and MySQL field names
    protected static $_propertyList = array('id' => 'UserID', 'name' => 'UserName', 'password' => 'UserPassword', 'birthday' => 'UserBirthday');
    
    // A method that fetches all users as an array
    public static function findAllUsers() {
        global $db;
        $sql = 'SELECT * FROM Users';
        $stmt = $db->query($sql);
        $users = array();
        while ($user = $stmt->fetchObject(__CLASS__)) {
            $users[] = $user;
        }
        return $users;
    }
    
    // Methods that fetch a specific user
    public static function findUserByName($name) {}
    public static function findUserById($name) {}
    
    // Methods for the current user object
    public function checkPassword($password) {return $this->password == $password;}
    public function showLink() {return "<a href=\"user.php?i={$this->id}\">{$this->name}</a>";}
}

// Then, you can create an instance of this class to insert a row in your table
$user = new User();
$user->name = 'oct1158';
$user->password = '789012';
$user->useFunction('birthday', 'NOW()');
echo 'Field birthday uses MySQL Function: ', $user->birthday, '<br>';
if ($user->insert()) {
    echo 'New User ID: ', $user->id, '<br>';
    
    // Update the row
    $user->password = '112233';
    $user->update();
} else {
    echo 'INSERT Failed<br>';
}
// Get a specific user by a query
$sql = 'SELECT * FROM Users WHERE UserName = ?';
$stmt = $dbh->prepare($sql);
$stmt->execute(array('admin'));
$admin_user = $stmt->fetchObject('User');
echo 'Admin ID is ', $admin_user->id, '.<br>';
echo 'Admin Birthday is ', $admin_user->birthday, '.<br>';

// Get all users by a static method of that class
$users = User::findAllUsers();
echo '<br>';
echo $users[0]->name, ', ', $users[0]->birthday, '<br>';
echo $users[1]->name, ', ', $users[1]->birthday, '<br>';
echo $users[2]->name, ', ', $users[2]->birthday, '<br>';
echo '<br>';

// Create an empty user and then delete it immediately
$user = new User();
$user->insert();
$user->delete();
?>
