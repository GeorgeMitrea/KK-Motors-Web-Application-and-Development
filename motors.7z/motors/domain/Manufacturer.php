<?php
class Manufacturer {

    public $id;
    public $name;

    public function __construct() {
    }

    // A method that fetches all manufacturers as an array
    public static function findAllManufacturers() {
        try {
            global $db;

            // Select all manufacturers
            $stmt = $db->query("SELECT * FROM manufacturer");
            $stmt->setFetchMode(PDO::FETCH_CLASS, 'Manufacturer');
            $manufacturers = array();

            while ($manufacturer = $stmt->fetch()) {
                $manufacturers[] = $manufacturer;
            }
            return $manufacturers;
        } catch(PDOException $ex) {
            $error = $ex->getMessage();
            throw new Exception($error);
        }
    }

    public static function findManufacturerByName($name) {
        try {
            global $db;

            // Find manufacturer by name
            $stmt = $db->prepare("SELECT * FROM manufacturer WHERE name=:name");
            $stmt->setFetchMode(PDO::FETCH_CLASS, 'Manufacturer');
            
            $params = array(
              'name' => $name
            );

            $stmt->execute($params);

            $manufacturer = $stmt->fetch();

            return $manufacturer;
        } catch(PDOException $ex) {
            $error = $ex->getMessage();
            throw new Exception($error);
        }
    }

    public static function findManufacturerById($id) {
        try {
            global $db;

            // Find manufacturer by name
            $stmt = $db->prepare("SELECT * FROM manufacturer WHERE id=:id");
            $stmt->setFetchMode(PDO::FETCH_CLASS, 'Manufacturer');

            $params = array(
              'id' => $id
            );

            $stmt->execute($params);

            $manufacturer = $stmt->fetch();

            return $manufacturer;
        } catch(PDOException $ex) {
            $error = $ex->getMessage();
            throw new Exception($error);
        }
    }

    public function insert() {
        try {
            global $db;
            // Begin an SQL transaction
            $db->beginTransaction();
            // Insert the manufacturer
            $stmt = $db->prepare("INSERT INTO manufacturer(name) VALUES(:name)");
            //Bind SQL prepared statement variables  with PHP variables
            $stmt->bindParam(':name', $this->name, PDO::PARAM_STR);
            // Execute SQL
            $stmt->execute();
            $db->commit();
        } catch(PDOException $ex) {
            //Something went wrong rollback!
            $db->rollBack();
            $error = $ex->getMessage();
            throw new Exception($error);
        }
    }
}
?>