<?php
class CarModel {

    public $id;
    public $name;
    public $manufacturer_id;
    public $manufacturer_name;

    public function __construct() {
    }

    // A method that fetches all car models as an array
    public static function findAllCarModels() {
        try {
            global $db;

            // Select all carModels
            $stmt = $db->query("SELECT * FROM car_model");
            $stmt->setFetchMode(PDO::FETCH_CLASS, 'CarModel');
            $carModels = array();

            while ($carModel = $stmt->fetch()) {
                $carModels[] = $carModel;
            }
            return $carModels;
        } catch(PDOException $ex) {
            $error = $ex->getMessage();
            throw new Exception($error);
        }
    }

    public static function findCarModelByNameAndManufacturerId($name, $manufacturer_id) {
        try {
            global $db;

            // Find carModel by name
            $stmt = $db->prepare("SELECT * FROM car_model WHERE name=:name and manufacturer_id=:manufacturer_id");
            $stmt->setFetchMode(PDO::FETCH_CLASS, 'CarModel');

            $params = array(
              'name' => $name,
              'manufacturer_id' => $manufacturer_id
            );

            $stmt->execute($params);

            $carModel = $stmt->fetch();
            
            return $carModel;
        } catch(PDOException $ex) {
            $error = $ex->getMessage();
            throw new Exception($error);
        }
    }

    public static function findCarModelById($id) {
        try {
            global $db;

            // Find carModel by name
            $stmt = $db->prepare("SELECT * FROM car_model WHERE id=:id");
            $stmt->setFetchMode(PDO::FETCH_CLASS, 'CarModel');

            $params = array(
              'id' => $id
            );

            $stmt->execute($params);

            $carModel = $stmt->fetch();
            
            return $carModel;
        } catch(PDOException $ex) {
            $error = $ex->getMessage();
            throw new Exception($error);
        }
    }

    public static function findCarModelsByManufacturerId($manufacturer_id) {
        try {
            global $db;

            // Find carModel by name
            $stmt = $db->prepare("SELECT * FROM car_model WHERE manufacturer_id=:manufacturer_id");
            $stmt->setFetchMode(PDO::FETCH_CLASS, 'CarModel');
            
            $params = array(
              'manufacturer_id' => $manufacturer_id
            );

            $stmt->execute($params);

            $carModels = array();

            while ($carModel = $stmt->fetch()) {
                $carModels[] = $carModel;
            }
            return $carModels;

        } catch(PDOException $ex) {
            $error = $ex->getMessage();
            throw new Exception($error);
        }
    }

    public function insert() {
        try {
            global $db;

            // Begin an SQL transaction
            $db->beginTransaction();

            $manufacturer = Manufacturer::findManufacturerByName($this->manufacturer_name);

            // Insert the car model
            $stmt = $db->prepare("INSERT INTO car_model(name,manufacturer_id) VALUES(:name,:manufacturer_id)");
            //Bind SQL prepared statement variables
            $stmt->bindParam(':name', $this->name, PDO::PARAM_STR);
            $stmt->bindParam(':manufacturer_id', $manufacturer->id, PDO::PARAM_INT);
            // Execute SQL
            $stmt->execute();
            $db->commit();
        } catch(PDOException $ex) {
            //Something went wrong rollback!
            $db->rollBack();
            $error = $ex->getMessage();
            throw new Exception($error);            
        }

    }

    public function delete() {}
    public function update() {}

}
?>