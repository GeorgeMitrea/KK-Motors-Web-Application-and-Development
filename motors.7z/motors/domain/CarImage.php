<?php
class CarImage {

    public $id;
    public $car_id;
    public $manufacturer_name;
    public $car_model_name;
    public $chassis_no;
    public $year;
    public $price;    
    public $image_url;

    public function __construct() {
    }

    // A method that fetches all car imagesas an array
    public static function findAllCarImages() {
        try {
            global $db;

            $pstmt = <<<EOT
SELECT 
    ma.name AS manufacturer_name,
    cm.name AS car_model_name,
    c.chassis_no AS chassis_no,
    c.year AS year,
    c.price AS price,
    ci.image_uri AS image_uri
FROM
    car AS c
        LEFT OUTER JOIN
    car_image AS ci ON ci.car_id = c.id
        LEFT OUTER JOIN
    car_model AS cm ON cm.id = c.car_model_id
        LEFT OUTER JOIN
    manufacturer AS ma ON ma.id = cm.manufacturer_id
order by ma.name, cm.name, c.year
EOT;

            // Find all car images
            $stmt = $db->query($pstmt);
            $stmt->setFetchMode(PDO::FETCH_CLASS, 'CarImage');

            $carImages = array();

            while ($carImage = $stmt->fetch()) {
                $carImages[] = $carImage;
            }
            
            return $carImages;

        } catch(PDOException $ex) {
            $error = $ex->getMessage();
            throw new Exception($error);
        }
    }

    // A method that fetches all car images as an array
    public static function findAllCarImagesByCarId($car_id) {
        try {
            global $db;

            // Find car model by car Id
            $stmt = $db->prepare("SELECT * FROM car_image WHERE car_id=:car_id");
            $stmt->setFetchMode(PDO::FETCH_CLASS, 'CarImage');
            
            $params = array(
              'car_id' => $car_id
            );

            $stmt->execute($params);

            $carImages = array();

            while ($carImage = $stmt->fetch()) {
                $carImages[] = $carImage;
            }
            
            return $carsImages;

        } catch(PDOException $ex) {
            $error = $ex->getMessage();
            throw new Exception($error);
        }
    }

    public function insert() {
        try {
            global $db;

            // Begin an SQL transaction
            $db->beginTransaction();
            // Insert the car model
            $stmt = $db->prepare("INSERT INTO car_image(car_id,image_url) VALUES(:car_id,:image_url)");
            //Bind SQL prepared statement variables
            $stmt->bindParam(':car_id', $car_id, PDO::PARAM_INT);
            $stmt->bindParam(':image_url', $image_url, PDO::PARAM_STR);
            // Execute SQL
            $stmt->execute();
            $db->commit();
        } catch(PDOException $ex) {
            //Something went wrong rollback!
            $db->rollBack();
            $error = $ex->getMessage();
            throw new Exception($error);
        }

    }

    public function delete() {}
    public function update() {}

}
?>