<?php
include_once 'CarModel.php';
include_once 'Manufacturer.php';

class Car {

    public $id;
    public $manufacturer_id;
    public $manufacturer_name;
    public $car_model_id;
    public $car_model_name;
    public $chassis_no;
    public $year;
    public $price;
        
    // A method that fetches all cars as an array
    public static function findAllCars() {
        try {
            global $db;

            // Select all cars
            $stmt = $db->query("SELECT * FROM car");
            $stmt->setFetchMode(PDO::FETCH_CLASS, 'Car');
            $cars = array();

            while ($car = $stmt->fetch()) {
                $cars[] = $car;
            }
            return $cars;
        } catch(PDOException $ex) {
            $error = $ex->getMessage();
            throw new Exception($error);
        }
    }

    public static function findCarById($id) {
        try {
            global $db;

            // Find car by name
            $stmt = $db->prepare("SELECT * FROM car WHERE id=:id");
            $stmt->setFetchMode(PDO::FETCH_CLASS, 'Car');

            $params = array(
              'id' => $id
            );

            $stmt->execute($params);

            $car = $stmt->fetch();

            return $car;
        } catch(PDOException $ex) {
            $error = $ex->getMessage();
            throw new Exception($error);
        }        
    }

    public static function findCarByManufacturerId($manufacturer_id) {
        try {
            global $db;

            // Find car by name
            $stmt = $db->query("SELECT * FROM car WHERE manufacturer_id=:manufacturer_id");
            $stmt->setFetchMode(PDO::FETCH_CLASS, 'Car');

            $params = array(
              'manufacturer_id' => $manufacturer_id
            );

            $stmt->execute($params);

            $cars = array();

            while ($car = $stmt->fetch()) {
                $cars[] = $car;
            }

            return $cars;

        } catch(PDOException $ex) {
            $error = $ex->getMessage();
            throw new Exception($error);
        }        
    }

    public static function findCarByModelId($model_id) {
        try {
            global $db;

            // Find car by name
            $stmt = $db->query("SELECT * FROM car WHERE model_id=:moldel_id");
            $stmt->setFetchMode(PDO::FETCH_CLASS, 'Car');
            
            $params = array(
              'model_id' => $model_id
            );

            $stmt->execute($params);

            $cars = array();

            while ($car = $stmt->fetch()) {
                $cars[] = $car;
            }
            
            return $cars;

        } catch(PDOException $ex) {
            $error = $ex->getMessage();
            throw new Exception($error);
        }        
    }

    public function insert() {
        try {
            global $db;

            // Begin an SQL transaction
            $db->beginTransaction();
            // Find manufacturer_id by name
            $manufacturer = Manufacturer::findManufacturerByName($this->manufacturer_name);
            $carModel =  CarModel::findCarModelByNameAndManufacturerId($this->car_model_name, $manufacturer->id);
            // Insert the car
            $stmt = $db->prepare("INSERT INTO car(manufacturer_id,car_model_id,chassis_no,year,price) 
                VALUES(:manufacturer_id,:car_model_id,:chassis_no,:year,:price)");
            //Bind SQL prepared statement variables with PHP variables
            $stmt->bindParam(':manufacturer_id', $manufacturer->id, PDO::PARAM_INT);
            $stmt->bindParam(':car_model_id', $carModel->id, PDO::PARAM_INT);
            $stmt->bindParam(':chassis_no', $this->chassis_no, PDO::PARAM_STR);
            $stmt->bindParam(':year', $this->year, PDO::PARAM_INT);
            $stmt->bindParam(':price', $this->price, PDO::PARAM_STR);
            // Execute SQL
            $stmt->execute();
            $db->commit();
        } catch(PDOException $ex) {
            //Something went wrong rollback!
            $db->rollBack();
            $error = $ex->getMessage();
            throw new Exception($error);
        }
    }
}
?>