(function($){
  $(function(){
    $('.slider').slider();
    $('.dropdown-button').dropdown();
    $('.button-collapse').sideNav();
    // $('.parallax').parallax();
    $('select').material_select();
    
    $(document).ready(function() {        
        $('.dropdown-button').dropdown();
        populateCarModel();

        function populateCarModel () {
            var manufacturerName = $('#manufacturerName').val();
            var carModelName = $('#carModelName').val();
            if(manufacturerName) {
                $.ajax({
                    type: "POST",
                    data: {manufacturerName: manufacturerName},
                    url: 'get-car-models.php',
                    dataType: 'json',
                    success: function(data, status) {
                        var $el = $("#carModelName");
                        $el.empty(); // remove old options
                        $el.append($("<option disabled selected></option>").attr("value", '').text('Choose Car Model'));
                        $.each(data, function(value, key) {
                            if(carModelName == key.name) {
                                $el.append($("<option selected></option>").attr("value", key.name).text(key.name));
                            } else{
                                $el.append($("<option></option>").attr("value", key.name).text(key.name));
                            }
                        });
                        $('select').material_select();
                    },
                    error: function(xhr, desc, err) {
                        console.log(xhr);
                        console.log("Details: " + desc + "\nError:" + err);
                    }
                });
            }
        };
    });
    $(document).on("change", '#manufacturerName', function(e) {
        var manufacturerName = $(this).val();
        $.ajax({
            type: "POST",
            data: {manufacturerName: manufacturerName},
            url: 'get-car-models.php',
            dataType: 'json',
            success: function(data, status) {
                var $el = $("#carModelName");
                $el.empty(); // remove old options
                $el.append($("<option disabled selected></option>").attr("value", '').text('Choose Car Model'));
                $.each(data, function(value, key) {
                    $el.append($("<option></option>").attr("value", key.name).text(key.name));
                });
                $('select').material_select();
            },
            error: function(xhr, desc, err) {
                console.log(xhr);
                console.log("Details: " + desc + "\nError:" + err);
            }
        });
    });
  }); // end of document ready
})(jQuery); // end of jQuery name space

