<?php
$servername = "localhost";
$username   = "Abeckley";
$password   = "Dean";
$dbname     = "display_images";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql    = "SELECT * FROM table1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {
        ?>
		 <img  src="<?php echo $row["images1"]; ?> " height="100" width="100"> <br>"<?php ;
    }
} else {
    echo "0 results";
}

$conn->close();
?>