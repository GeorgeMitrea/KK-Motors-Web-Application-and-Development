<?php

header("content-type:application/json");

include_once 'dbconnect';

include_once 'domain/Manufacturer.php';
include_once 'domain/CarModel.php';

// if(!isset($_SESSION['usr_id'])) {
	// header("Location: index.php?page=login");
// }

$carModels =  array();

if (isset($_POST['manufacturerName'])) {
	$manufacturerName = (array_key_exists('manufacturerName', $_POST) ? $_POST['manufacturerName'] : '');
	error_log('manufacturer name:' . $manufacturerName);

	try {
		$manufacturer = Manufacturer::findManufacturerByName($manufacturerName);
		$carModels =  CarModel::findCarModelsByManufacturerId($manufacturer->id);
	} catch (Exception $ex) {
		$errormsg = $ex->getMessage();
		error_log($errormsg);
	}
}

echo json_encode($carModels);
?>